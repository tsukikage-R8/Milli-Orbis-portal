# MilliOrbis Cursors — All Talents Bundle

各タレントフォルダに `install.inf` が入っています。各フォルダで右クリック → インストール してください。

- Scheme名: `MilliOrbis-{Konomi|Nono|...}`
- 1タレントあたり15種
- Windows 10/11 対応

## ライセンス

- 個人で楽しむ範囲での利用のみ可。再配布・転載・販売・商用利用はすべて禁止です。詳細は `LICENSE` を参照してください。
