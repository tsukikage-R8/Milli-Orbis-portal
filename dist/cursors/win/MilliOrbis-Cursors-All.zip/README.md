# MilliOrbis Cursors — All Talents Bundle

各タレントフォルダに `install.inf` が入っています。各フォルダで右クリック → インストール してください。

- Scheme名: `MilliOrbis-{Konomi|Nono|...}`
- 1タレントあたり15種
- Windows 10/11 対応
