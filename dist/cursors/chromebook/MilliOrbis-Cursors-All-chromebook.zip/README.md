# MilliOrbis Cursors — All chromebook Bundle

各タレントの png セットです。

## ライセンス

- 個人で楽しむ範囲での利用のみ可。再配布・転載・販売・商用利用はすべて禁止です。詳細は `LICENSE` を参照してください。
