# MilliOrbis 小廻こま Cursors for Chromebook

![preview](preview.png)

**小廻こま（Koma）** のオリジナルカーソル 15種を Chromebook の Chrome ブラウザで使えます。

> **Chromebook のシステム全体**ではカスタム画像のカーソルは OS制限で直接変更できません。**Chromeブラウザ内**でのみ有効です（Chromebookの主用途はブラウザのため実用上は十分です）。

## インストール（Chromebook）— 拡張で適用

1. Chromeウェブストアで [Custom Cursor for Chrome](https://chrome.google.com/webstore/detail/custom-cursor-for-chrome/ogdlpmhglpejoiomcodnpjnfgcpmgale) を `Add to Chrome` → `Add extension`
2. 拡張の管理画面（`chrome://extensions` → `Details` → `Extension options` または拡張アイコン → `Manage`）で `Upload cursor` から本 `MilliOrbis-Koma-chromebook.zip` を解凍した `png/` 内の `png` を登録
   - 対応: `arrow=Normal`, `hand=Pointer`, `beam=Text`, `wait=Busy` 等（詳細は `hotspot.json` を参照）
3. 必要なら `Chromebook Settings → Accessibility → Cursor` でサイズ調整

## サイト内での利用

Chromebook でも `cursors.html` の `サイトで試す` やヘッダーの `カーソル` から即時切り替えできます。

## ファイル

- `png/*.png` — 15種の透過PNG（32px）
- `hotspot.json` — 各pngのホットスポット座標
- `preview.png` — プレビュー
