# MilliOrbis 小廻こま Cursors for Mac

![preview](preview.png)

**小廻こま（Koma）** のオリジナルカーソル 15種（`arrow` / `appstar` / `beam` / `cross` / `hand` / `help` / `move` / `no` / `pen` / `person` / `sizenesw` / `sizens` / `sizenwse` / `sizewe` / `wait`）を Mac で使えます。サイト内のカーソル切替は Mac のブラウザでも既に動作しますが、**システム全体**で使う場合は下記手順で適用してください。

## インストール（Mac）— Mousecape でワンクリック

1. [Mousecape](https://github.com/alexzielenski/Mousecape/releases) をダウンロード → `Mousecape.zip` を解凍 → `Mousecape.app` を `Applications` に移動 → 起動
2. 初回は `System Settings → Privacy & Security → Accessibility` で `Mousecape` を許可（ONにする）
3. 本 `MilliOrbis-Koma-mac.zip` を解凍 → 中の `MilliOrbis-Koma.cape` を **ダブルクリック** → Mousecapeに自動登録されます → リストから `MilliOrbis-Koma` を選択 → `Apply`

> `MilliOrbis-Koma.cape` は15種を一括登録するMousecape用ファイルです（Windowsの `install.inf` に相当）。ダブルクリックで完了し、手動のドラッグ＆ドロップは不要です。
> 旧来の手動登録も可能: `png/` 内の15枚を `File → New Cape` にドラッグ＆ドロップ（`hotspot.json` 参照）でも適用できます。

## サイト内での利用（Macでも即時）

Mac の Chrome / Safari でも `cursors.html` の `サイトで試す` ボタンやヘッダーの `カーソル` から即時切り替えできます（CSS `png` フォールバック）。

## ファイル

- `MilliOrbis-Koma.cape` — **ワンクリック登録用**（Mousecapeでダブルクリック）
- `png/*.png` — 15種の透過PNG（32px、手動登録用フォールバック）
- `hotspot.json` — 各pngのホットスポット座標
- `preview.png` — プレビュー

## ライセンス

- 個人で楽しむ範囲での利用のみ可。**再配布・転載・販売・商用利用はすべて禁止**です。
- 詳細は同梱の `LICENSE` を参照してください。
- Cursor design: すんすん (@SunSunmachi)
