# MilliOrbis Cursors — All Mac Bundle

各タレントの .cape (ワンクリック) + png セットです。`*.cape` をダブルクリックで Mousecape に一括登録できます。
