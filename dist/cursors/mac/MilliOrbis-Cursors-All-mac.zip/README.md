# MilliOrbis Cursors — All Mac Bundle

各タレントの .cape (ワンクリック) + png セットです。`*.cape` をダブルクリックで Mousecape に一括登録できます。

## ライセンス

- 個人で楽しむ範囲での利用のみ可。再配布・転載・販売・商用利用はすべて禁止です。詳細は `LICENSE` を参照してください。
